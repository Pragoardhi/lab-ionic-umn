const controller = document.querySelector('ion-alert-controller');
const bhapus = document.querySelector('.hapus');
const btambah = document.querySelector('.tambah');
bhapus.addEventListener('click', HapusButtonClick);
btambah.addEventListener('click', TambahButtonClick);

var TambahNP = [];
var TambahJP = [];
var index = 0;



function HapusButtonClick() {
    var checkName = document.getElementById("NPengeluaran").value;
    var checkJumlah = document.getElementById("JPengeluaran").value;
    var i;
    if (checkName == "" || checkJumlah == "") {
        TampilAlert();
    } else if (TambahNP.length == 0 || TambahNP.length == null) {
        TampilAlertHapus();
    }
    else {
        for (i = 0; i < TambahNP.length; i++) {
            console.log("Jumlah i " + i);
            if (TambahNP[i].includes(checkName) == true && TambahJP[i] == checkJumlah) {
                TambahJP.splice(i, 1);
                TambahNP.splice(i, 1);
                console.log("saya jalan " + i);
            }
        }
        TampilList();
    }
}

function TambahButtonClick() {
    var NamaPengeluaran = document.getElementById("NPengeluaran").value;
    var JumlahPengeluaran = document.getElementById("JPengeluaran").value;
    if (NamaPengeluaran == "" || JumlahPengeluaran == "") {
        TampilAlert();
    } else {
        if (TambahNP.includes(NamaPengeluaran) == true && TambahJP.includes(JumlahPengeluaran) == true) {
            TampilAlertTambah();

        } else {
            TambahNP.push(NamaPengeluaran);
            TambahJP.push(JumlahPengeluaran);
            TampilList();
        }
    }
}

function TampilList() {
    var total = 0;
    //console.log("Banyak array : " + TambahNP.length);
    document.getElementById("Rincian").innerHTML = "";
    if (TambahNP.length == 0) {
        var print = "Total Pengeluaran : Rp. 0,00";
        document.getElementById("Total").innerHTML = print;
    }
    for (i = 0; i < TambahNP.length; i++) {
        var list = document.createElement("ion-item");
        var TNP = document.createTextNode(TambahNP[i]);
        var TJP = document.createTextNode(TambahJP[i]);
        list.append(TNP, ": Rp. ", TJP, ",00");
        total = total + parseInt(TambahJP[i]);
        var print = "Total Pengeluaran : Rp. " + total + ",00";
        document.getElementById("Rincian").appendChild(list);
        document.getElementById("Total").innerHTML = print;
    }
}

function TampilAlertTambah() {
    controller.create({
        header: 'Terjadi Kesalahan',
        message: 'Mohon masukkan nama dan jumlah pengeluaran yang lain',
        buttons: ['Tutup']
    }).then(alert => {
        alert.present();
    });
}

function TampilAlert() {
    controller.create({
        header: 'Terjadi Kesalahan',
        message: 'Mohon masukkan nama dan jumlah pengeluaran',
        buttons: ['Tutup']
    }).then(alert => {
        alert.present();
    });
}

function TampilAlertHapus() {
    controller.create({
        header: 'Terjadi Kesalahan',
        message: 'Daftar nama dan jumlah pengeluaran tidak tersedia',
        buttons: ['Tutup']
    }).then(alert => {
        alert.present();
    });
}
