import { Injectable } from '@angular/core';
import { Place } from './place.model';

@Injectable({
  providedIn: 'root'
})
export class PlacesService {

  private _places: Place[] = [
    new Place(
      'p1',
      'Gading Apartment',
      '2BR, Luas dan Cozy',
      'https://jendela360.com/gallery/apartment/gading-icon58a56de27674b.jpg',
      10000000000
    ),
    new Place(
      'p2',
      'Serpong Apartment',
      'Apartemen Romantis',
      'https://d3p0bla3numw14.cloudfront.net/news-content/img/2017/01/16110710/perspektif-dan-stasiun-cisauk-OK.jpg',
      125000000
    ),
    new Place(
      'p3',
      'BSD Apartment',
      'Apartemen Murah',
      'https://s4.rea.global/img/668x501-resize/rumah/id/6e34239e5e71441de4d2965e1f027e03.jpg',
      50000000
    )
  ];

  get places() {
    return [...this._places];
  }
}
